#! /usr/bin/env python3

import unittest

import pycotap

unittest.main(module = None, testRunner = pycotap.TAPTestRunner)
